<?php

declare(strict_types=1);

namespace App\Domain\Rules\Calibration;

use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Log;

final class MonteCarloEvaluator
{
    private const MIN_TRADES_PER_DAY = 0.3;

    private const MAX_DRAWDOWN_THRESHOLD = 0.15; // 15%

    private const MAX_MONTHLY_LOSS_PROB = 0.25; // 25%

    // Keep a default constant for non-configured environments
    private const DEFAULT_MONTE_CARLO_RUNS = 200;

    /**
     * Evaluate top candidates with Monte Carlo simulation
     */
    public function evaluate(Collection $scores, CalibrationDataset $dataset, int $topN = 10, ?int $runs = null): Collection
    {
        // Fast-path for tests or when MC_SKIP is enabled: return compatible
        // shaped results without running expensive simulations so unit and
        // integration tests complete quickly.
        $mcSkip = (bool) config('calibration.mc_skip', false) || app()->environment('testing');
        if ($mcSkip) {
            // Mirror the pre-filtering logic so candidates that would normally
            // be rejected (low trades per day or negative expectancy) are still
            // filtered out even when skipping expensive simulations.
            $validCandidates = $scores->filter(function (CandidateScore $score) {
                $tradesPerDay = $score->metrics['trades_per_day'] ?? 0;
                $expectancy = $score->metrics['expectancy'] ?? 0.0;

                if ($expectancy <= 0) {
                    return false;
                }

                return $tradesPerDay >= self::MIN_TRADES_PER_DAY;
            })->values();

            return $validCandidates->map(static function (CandidateScore $score) {
                $expectancy = $score->metrics['expectancy'] ?? 0.0;

                return new CandidateScore(
                    candidate: $score->candidate,
                    metrics: array_merge($score->metrics ?? [], [
                        'expectancy' => $expectancy,
                        'monte_carlo_runs' => 0,
                    ]),
                    riskMetrics: [
                        'p95_drawdown' => 0.0,
                        'monthly_loss_probability' => 0.0,
                        'value_at_risk' => 0.0,
                        'sharpe_ratio' => 0.0,
                        'avg_annual_return' => 0.0,
                        'return_volatility' => 0.0,
                    ]
                );
            })->values();
        }
        // Allow config to override runs; use budgets.mc_runs primarily
        $configuredRuns = $runs ?? (int) config('calibration.budgets.mc_runs', (int) config('calibration.monte_carlo_runs', self::DEFAULT_MONTE_CARLO_RUNS));
        if (app()->environment('testing')) {
            $configuredRuns = (int) config('calibration.monte_carlo_runs_testing', max(0, (int) $configuredRuns / 10));
        }

        Log::info('monte_carlo_evaluation_started', [
            'input_candidates' => $scores->count(),
            'evaluating_top' => $topN,
            'runs_per_candidate' => $configuredRuns,
        ]);

        // Pre-filter candidates by trade frequency (already done in scoring, but double-check)
        $validCandidates = $scores->filter(function (CandidateScore $score) {
            $tradesPerDay = $score->metrics['trades_per_day'] ?? 0;

            return $tradesPerDay >= self::MIN_TRADES_PER_DAY;
        });

        if ($validCandidates->isEmpty()) {
            Log::warning('monte_carlo_no_valid_candidates', [
                'reason' => 'all_candidates_below_trade_frequency_threshold',
                'threshold' => self::MIN_TRADES_PER_DAY,
            ]);

            return collect();
        }

        $take = $validCandidates->take($topN)->values();

        $evaluated = $take->map(function (CandidateScore $score, int $index) use ($dataset, $configuredRuns) {
            return $this->runMonteCarloSimulation($score, $dataset, $index, $configuredRuns);
        })->filter(); // Remove null results (failed simulations)

        // Final filtering by drawdown and risk thresholds
        $finalCandidates = $evaluated->filter(function (CandidateScore $score) {
            $riskMetrics = $score->riskMetrics ?? [];
            $drawdown = $riskMetrics['p95_drawdown'] ?? 1.0;
            $lossProb = $riskMetrics['monthly_loss_probability'] ?? 1.0;

            $passesDrawdown = $drawdown <= self::MAX_DRAWDOWN_THRESHOLD;
            $passesLossProb = $lossProb <= self::MAX_MONTHLY_LOSS_PROB;

            if (! $passesDrawdown || ! $passesLossProb) {
                Log::debug('candidate_failed_risk_thresholds', [
                    'candidate_id' => $score->candidate->id,
                    'drawdown' => $drawdown,
                    'loss_prob' => $lossProb,
                    'passes_drawdown' => $passesDrawdown,
                    'passes_loss_prob' => $passesLossProb,
                ]);

                return false;
            }

            return true;
        });

        Log::info('monte_carlo_evaluation_completed', [
            'candidates_simulated' => $take->count(),
            'candidates_passing_thresholds' => $finalCandidates->count(),
            'max_drawdown_threshold' => self::MAX_DRAWDOWN_THRESHOLD,
            'max_loss_prob_threshold' => self::MAX_MONTHLY_LOSS_PROB,
        ]);

        return $finalCandidates->values();
    }

    /**
     * Run Monte Carlo simulation for a single candidate
     */
    private function runMonteCarloSimulation(CandidateScore $score, CalibrationDataset $dataset, int $index, int $runs): ?CandidateScore
    {
        $candidate = $score->candidate;
        $metrics = $score->metrics;

        $hitRate = $metrics['hit_rate'] ?? 0.6;
        $tradesPerDay = $metrics['trades_per_day'] ?? 1.0;
        $expectancy = $metrics['expectancy'] ?? 0.0;

        if ($expectancy <= 0) {
            Log::debug('candidate_skipped_negative_expectancy', [
                'candidate_id' => $candidate->id,
                'expectancy' => $expectancy,
            ]);

            return null;
        }

        // Simulation parameters
        $tradingDays = 252; // Full year
        $totalTrades = (int) round($tradesPerDay * $tradingDays);

        if ($totalTrades < 76) { // Less than ~0.3 trades/day for a year
            Log::debug('candidate_skipped_insufficient_trades', [
                'candidate_id' => $candidate->id,
                'total_trades_per_year' => $totalTrades,
                'trades_per_day' => $tradesPerDay,
            ]);

            return null;
        }

        // Run multiple Monte Carlo simulations
        $seed = crc32($candidate->id . $dataset->tag . 'mc');
        $simulations = $this->runSimulations($hitRate, $expectancy, $totalTrades, $seed, $runs);

        // Calculate risk metrics from simulation results
        $riskMetrics = $this->calculateRiskMetrics($simulations);

        Log::debug('monte_carlo_simulation_completed', [
            'candidate_id' => $candidate->id,
            'total_trades' => $totalTrades,
            'simulations_run' => count($simulations),
            'risk_metrics' => $riskMetrics,
        ]);

        return new CandidateScore(
            candidate: $score->candidate,
            metrics: array_merge($score->metrics, [
                'total_trades_simulated' => $totalTrades,
                'monte_carlo_runs' => count($simulations),
            ]),
            riskMetrics: $riskMetrics,
        );
    }

    /**
     * Run Monte Carlo simulations
     */
    private function runSimulations(float $hitRate, float $expectancy, int $totalTrades, int $seed, int $runs): array
    {
        $simulations = [];

        // Estimate average win/loss from expectancy and hit rate
        // expectancy = hitRate * avgWin + (1-hitRate) * avgLoss
        // Assume avgLoss = -1R, solve for avgWin
        $avgLoss = -1.0;
        $avgWin = ($expectancy - (1 - $hitRate) * $avgLoss) / max($hitRate, 0.01);
        $avgWin = max(1.0, $avgWin); // Minimum 1R win

        for ($run = 0; $run < $runs; $run++) {
            mt_srand($seed + $run);

            $equity = 1.0; // Start with $1 (100%)
            $peakEquity = 1.0;
            $maxDrawdown = 0.0;
            $monthlyReturns = [];
            $currentMonthReturn = 0.0;
            $tradesInMonth = 0;

            for ($trade = 0; $trade < $totalTrades; $trade++) {
                // Determine if trade wins or loses
                $isWin = mt_rand(1, 10000) <= ($hitRate * 10000);
                $tradeReturn = $isWin ? ($avgWin / 100) : ($avgLoss / 100); // Convert R to percentage

                $equity *= (1 + $tradeReturn);
                $currentMonthReturn += $tradeReturn;
                $tradesInMonth++;

                // Track peak and drawdown
                if ($equity > $peakEquity) {
                    $peakEquity = $equity;
                } else {
                    $drawdown = ($peakEquity - $equity) / $peakEquity;
                    $maxDrawdown = max($maxDrawdown, $drawdown);
                }

                // Monthly periods (assume ~21 trades per month for daily trading)
                if ($tradesInMonth >= 21 || $trade === $totalTrades - 1) {
                    $monthlyReturns[] = $currentMonthReturn;
                    $currentMonthReturn = 0.0;
                    $tradesInMonth = 0;
                }
            }

            $simulations[] = [
                'final_equity' => $equity,
                'max_drawdown' => $maxDrawdown,
                'monthly_returns' => $monthlyReturns,
                'total_return' => $equity - 1.0,
            ];
        }

        return $simulations;
    }

    /**
     * Calculate risk metrics from simulation results
     */
    private function calculateRiskMetrics(array $simulations): array
    {
        if (empty($simulations)) {
            return [
                'p95_drawdown' => 1.0,
                'monthly_loss_probability' => 1.0,
                'value_at_risk' => 1.0,
                'sharpe_ratio' => 0.0,
            ];
        }

        // Extract metrics
        $drawdowns = array_column($simulations, 'max_drawdown');
        $totalReturns = array_column($simulations, 'total_return');
        $allMonthlyReturns = [];

        foreach ($simulations as $sim) {
            $allMonthlyReturns = array_merge($allMonthlyReturns, $sim['monthly_returns']);
        }

        // Sort for percentile calculations
        sort($drawdowns);
        sort($totalReturns);
        sort($allMonthlyReturns);

        // Calculate P95 drawdown (95th percentile - worst 5% of outcomes)
        $p95Index = (int) round(count($drawdowns) * 0.95) - 1;
        $p95Drawdown = $drawdowns[max(0, $p95Index)] ?? 0.0;

        // Calculate monthly loss probability
        $lossingMonths = array_filter($allMonthlyReturns, fn($ret) => $ret < 0);
        $monthlyLossProb = count($lossingMonths) / max(1, count($allMonthlyReturns));

        // Calculate Value at Risk (95th percentile of losses)
        $losses = array_filter($totalReturns, fn($ret) => $ret < 0);
        if (! empty($losses)) {
            sort($losses);
            $varIndex = (int) round(count($losses) * 0.95) - 1;
            $var = abs($losses[max(0, $varIndex)] ?? 0.0);
        } else {
            $var = 0.0;
        }

        // Calculate Sharpe ratio approximation
        $avgReturn = array_sum($totalReturns) / count($totalReturns);
        $returnStdDev = $this->calculateStandardDeviation($totalReturns);
        $sharpeRatio = $returnStdDev > 0 ? $avgReturn / $returnStdDev : 0.0;

        return [
            'p95_drawdown' => round($p95Drawdown, 4),
            'monthly_loss_probability' => round($monthlyLossProb, 4),
            'value_at_risk' => round($var, 4),
            'sharpe_ratio' => round($sharpeRatio, 3),
            'avg_annual_return' => round($avgReturn, 4),
            'return_volatility' => round($returnStdDev, 4),
        ];
    }

    /**
     * Calculate standard deviation
     */
    private function calculateStandardDeviation(array $values): float
    {
        if (count($values) < 2) {
            return 0.0;
        }

        $mean = array_sum($values) / count($values);
        $variance = array_sum(array_map(fn($x) => pow($x - $mean, 2), $values)) / count($values);

        return sqrt($variance);
    }
}
