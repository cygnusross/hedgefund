<?php

declare(strict_types=1);

use App\Domain\Decision\LiveDecisionEngine;
use App\Domain\Rules\AlphaRules;

it('applies confidence reduction during avoided Asian session', function () {
    // Create rules YAML with session filtering
    $rulesYaml = <<<'YAML'
schema_version: "1.1"
gates: {}
confluence: {}
risk: {}
execution: {}
cooldowns: {}
overrides: {}
session_filters:
    default:
        avoid_sessions:
            asian:
                start: "22:00"
                end: "06:00"
YAML;

    $path = tempnam(sys_get_temp_dir(), 'alpharules').'.yaml';
    file_put_contents($path, $rulesYaml);
    $rules = new AlphaRules($path);
    $rules->reload();

    // Create test context during Asian session (2 AM GMT)
    $ctx = [
        'meta' => ['pair_norm' => 'EURUSD', 'data_age_sec' => 10],
        'market' => [
            'status' => 'TRADEABLE',
            'last_price' => 1.1000,
            'atr5m_pips' => 10,
            'spread_estimate_pips' => 0.5,
            'sentiment' => ['long_pct' => 60.0, 'short_pct' => 40.0],
        ],
        'features' => ['trend30m' => 'up'],
        'calendar' => ['within_blackout' => false],
    ];

    // Mock current time to 2 AM GMT (within Asian session)
    $asianTime = new DateTimeImmutable('2025-01-01 02:00:00', new DateTimeZone('UTC'));

    // Use reflection to test private method getSessionMultiplier
    $engine = new LiveDecisionEngine($rules);
    $reflection = new ReflectionClass($engine);
    $method = $reflection->getMethod('getSessionMultiplier');
    $method->setAccessible(true);

    $multiplier = $method->invokeArgs($engine, [$asianTime]);
    expect($multiplier)->toBe(0.7); // 30% reduction for avoided session

    // Clean up temp file
    unlink($path);
});

it('applies normal confidence during London session', function () {
    // Create rules YAML with session filtering
    $rulesYaml = <<<'YAML'
schema_version: "1.1"
gates: {}
confluence: {}
risk: {}
execution: {}
cooldowns: {}
overrides: {}
session_filters:
    default:
        avoid_sessions:
            asian:
                start: "22:00"
                end: "06:00"
YAML;

    $path = tempnam(sys_get_temp_dir(), 'alpharules').'.yaml';
    file_put_contents($path, $rulesYaml);
    $rules = new AlphaRules($path);
    $rules->reload();

    // Mock current time to 10 AM GMT (London session)
    $londonTime = new DateTimeImmutable('2025-01-01 10:00:00', new DateTimeZone('UTC'));

    // Use reflection to test private method
    $engine = new LiveDecisionEngine($rules);
    $reflection = new ReflectionClass($engine);
    $method = $reflection->getMethod('getSessionMultiplier');
    $method->setAccessible(true);

    $multiplier = $method->invokeArgs($engine, [$londonTime]);
    expect($multiplier)->toBe(1.0); // Normal confidence during allowed session

    // Clean up temp file
    unlink($path);
});

it('applies normal confidence when no session filters configured', function () {
    // Create rules YAML without session filtering
    $rulesYaml = <<<'YAML'
schema_version: "1.1"
gates: {}
confluence: {}
risk: {}
execution: {}
cooldowns: {}
overrides: {}
YAML;

    $path = tempnam(sys_get_temp_dir(), 'alpharules').'.yaml';
    file_put_contents($path, $rulesYaml);
    $rules = new AlphaRules($path);
    $rules->reload();

    $anyTime = new DateTimeImmutable('2025-01-01 02:00:00', new DateTimeZone('UTC'));

    // Use reflection to test private method
    $engine = new LiveDecisionEngine($rules);
    $reflection = new ReflectionClass($engine);
    $method = $reflection->getMethod('getSessionMultiplier');
    $method->setAccessible(true);

    $multiplier = $method->invokeArgs($engine, [$anyTime]);
    expect($multiplier)->toBe(1.0); // Normal confidence when no session filters configured

    // Clean up temp file
    unlink($path);
});

it('applies confidence boost during preferred sessions', function () {
    // Create rules YAML with preferred session filtering
    $rulesYaml = <<<'YAML'
schema_version: "1.1"
gates: {}
confluence: {}
risk: {}
execution: {}
cooldowns: {}
overrides: {}
session_filters:
    default:
        preferred_sessions:
            london_ny_overlap:
                start: "13:00"
                end: "17:00"
YAML;

    $path = tempnam(sys_get_temp_dir(), 'alpharules').'.yaml';
    file_put_contents($path, $rulesYaml);
    $rules = new AlphaRules($path);
    $rules->reload();

    // Mock current time to 14:00 GMT (within London-NY overlap)
    $overlapTime = new DateTimeImmutable('2025-01-01 14:00:00', new DateTimeZone('UTC'));

    // Use reflection to test private method
    $engine = new LiveDecisionEngine($rules);
    $reflection = new ReflectionClass($engine);
    $method = $reflection->getMethod('getSessionMultiplier');
    $method->setAccessible(true);

    $multiplier = $method->invokeArgs($engine, [$overlapTime]);
    expect($multiplier)->toBe(1.2); // 20% confidence boost for preferred session

    // Clean up temp file
    unlink($path);
});
