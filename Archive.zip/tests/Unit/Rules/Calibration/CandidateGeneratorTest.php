<?php

declare(strict_types=1);

use App\Domain\Rules\Calibration\CalibrationConfig;
use App\Domain\Rules\Calibration\CalibrationDataset;
use App\Domain\Rules\Calibration\CandidateGenerator;
use App\Domain\Rules\ResolvedRules;
use Carbon\CarbonImmutable;
use Illuminate\Foundation\Testing\TestCase;
use Illuminate\Support\Collection;

uses(TestCase::class);

it('generates comprehensive coarse grid with parameter constraints', function () {
    $generator = new CandidateGenerator;

    // Create baseline rules
    $baseRules = [
        'gates' => [
            'adx_min' => 24,
            'sentiment' => ['mode' => 'contrarian'],
        ],
        'execution' => [
            'rr' => 2.0,
            'sl_atr_mult' => 2.0,
            'tp_atr_mult' => 4.0,
        ],
        'risk' => [
            'per_trade_pct' => ['default' => 1.0],
        ],
    ];

    $baseline = new ResolvedRules(
        base: $baseRules,
        marketOverrides: [],
        emergencyOverrides: [],
        metadata: [],
        tag: 'test-baseline'
    );

    $config = new CalibrationConfig(
        tag: '2025-W38',
        periodStart: CarbonImmutable::create(2025, 9, 15),
        periodEnd: CarbonImmutable::create(2025, 9, 21),
        dryRun: false,
        activate: true,
        shadowMode: false
    );

    $dataset = new CalibrationDataset(
        tag: '2025-W38',
        markets: ['EURUSD', 'GBPUSD'],
        snapshots: [],
        regimeSummary: [],
        costEstimates: []
    );

    $candidates = $generator->generate($config, $baseline, $dataset);

    // Filter only grid candidates (exclude baseline)
    $gridCandidates = $candidates->filter(fn ($c) => ($c->metadata['stage'] ?? null) === 'grid');

    // Should have diverse parameter combinations
    $adxValues = $gridCandidates->pluck('metadata.adx_min')->filter()->unique();
    $sentimentModes = $gridCandidates->pluck('metadata.sentiment')->filter()->unique();
    $rrValues = $gridCandidates->pluck('metadata.rr')->filter()->unique();

    // Should have diverse parameter combinations

    // Should generate comprehensive grid with good parameter coverage
    expect($candidates)->toBeInstanceOf(Collection::class);
    expect($candidates->count())->toBeGreaterThan(50); // At least substantial grid
    expect($candidates->count())->toBeLessThan(350); // But not excessive

    // First candidate should be baseline
    $first = $candidates->first();
    expect($first->id)->toBe('2025-W38-baseline');
    expect($first->metadata['stage'])->toBe('baseline');

    expect($adxValues->count())->toBeGreaterThanOrEqual(4); // Multiple ADX thresholds
    expect($sentimentModes)->toContain('contrarian');
    expect($sentimentModes)->toContain('confirming');
    expect($rrValues->count())->toBeGreaterThanOrEqual(4); // Multiple RR ratios
});

it('validates parameter constraints during generation', function () {
    $generator = new CandidateGenerator;

    $baseRules = [
        'gates' => ['adx_min' => 24, 'sentiment' => ['mode' => 'contrarian']],
        'execution' => ['rr' => 2.0, 'sl_atr_mult' => 2.0, 'tp_atr_mult' => 4.0],
        'risk' => ['per_trade_pct' => ['default' => 1.0]],
    ];

    $baseline = new ResolvedRules(
        base: $baseRules,
        marketOverrides: [],
        emergencyOverrides: [],
        metadata: [],
        tag: 'test-validation'
    );

    $config = new CalibrationConfig(
        tag: '2025-W39',
        periodStart: CarbonImmutable::create(2025, 9, 22),
        periodEnd: CarbonImmutable::create(2025, 9, 28),
        dryRun: false,
        activate: false,
        shadowMode: false
    );

    $dataset = new CalibrationDataset('2025-W39', [], [], [], []);

    $candidates = $generator->generate($config, $baseline, $dataset);

    // All candidates should have valid parameter ranges
    $candidates->each(function ($candidate) {
        if (isset($candidate->metadata['rr'])) {
            $rr = $candidate->metadata['rr'];
            expect($rr)->toBeGreaterThanOrEqual(1.25); // Minimum viable RR
        }

        if (isset($candidate->metadata['sl_atr_mult'])) {
            $slMult = $candidate->metadata['sl_atr_mult'];
            expect($slMult)->toBeGreaterThanOrEqual(1.5); // Minimum stop distance
        }

        if (isset($candidate->metadata['risk_pct'])) {
            $risk = $candidate->metadata['risk_pct'];
            expect($risk)->toBeGreaterThanOrEqual(0.5);
            expect($risk)->toBeLessThanOrEqual(2.0);
        }
    });
});

it('generates refinements around top candidates', function () {
    $generator = new CandidateGenerator;

    // Mock top-performing candidates
    $topCandidates = collect([
        new \App\Domain\Rules\Calibration\CalibrationCandidate(
            id: '2025-W40-top-1',
            baseRules: [
                'gates' => ['adx_min' => 26, 'sentiment' => ['mode' => 'contrarian']],
                'execution' => ['rr' => 2.25, 'sl_atr_mult' => 2.0, 'tp_atr_mult' => 4.5],
                'risk' => ['per_trade_pct' => ['default' => 1.25]],
            ],
            marketOverrides: [],
            metadata: ['stage' => 'grid', 'score' => 0.85]
        ),
    ]);

    $baseline = new ResolvedRules(
        base: [],
        marketOverrides: [],
        emergencyOverrides: [],
        metadata: [],
        tag: 'test'
    );

    $config = new CalibrationConfig(
        tag: '2025-W40',
        periodStart: CarbonImmutable::create(2025, 9, 29),
        periodEnd: CarbonImmutable::create(2025, 10, 5),
        dryRun: false,
        activate: false,
        shadowMode: false
    );

    $refinements = $generator->refineTopCandidates($topCandidates, $config, $baseline);

    expect($refinements)->toBeInstanceOf(Collection::class);
    expect($refinements->count())->toBeGreaterThan(0);

    // Should generate variations around the top candidate
    $refinements->each(function ($candidate) {
        expect($candidate->metadata['stage'])->toBe('refined');
        expect($candidate->metadata['parent_id'])->toBe('2025-W40-top-1');
    });
});

it('maintains RR consistency in generated candidates', function () {
    $generator = new CandidateGenerator;

    $baseRules = [
        'gates' => ['adx_min' => 24, 'sentiment' => ['mode' => 'contrarian']],
        'execution' => ['rr' => 2.0, 'sl_atr_mult' => 2.0, 'tp_atr_mult' => 4.0],
        'risk' => ['per_trade_pct' => ['default' => 1.0]],
    ];

    $baseline = new ResolvedRules(
        base: $baseRules,
        marketOverrides: [],
        emergencyOverrides: [],
        metadata: [],
        tag: 'test-consistency'
    );

    $config = new CalibrationConfig(
        tag: '2025-W41',
        periodStart: CarbonImmutable::create(2025, 10, 6),
        periodEnd: CarbonImmutable::create(2025, 10, 12),
        dryRun: false,
        activate: false,
        shadowMode: false
    );

    $dataset = new CalibrationDataset('2025-W41', [], [], [], []);

    $candidates = $generator->generate($config, $baseline, $dataset);

    // Check RR consistency: TP multiplier should equal SL multiplier * RR
    $candidates->filter(fn ($c) => $c->metadata['stage'] ?? null === 'grid')
        ->each(function ($candidate) {
            $baseRules = $candidate->baseRules;
            $rr = $baseRules['execution']['rr'] ?? 2.0;
            $slMult = $baseRules['execution']['sl_atr_mult'] ?? 2.0;
            $tpMult = $baseRules['execution']['tp_atr_mult'] ?? 4.0;

            $expectedTpMult = $slMult * $rr;
            expect(abs($tpMult - $expectedTpMult))->toBeLessThan(0.1);
        });
});

it('generates unique candidate IDs', function () {
    $generator = new CandidateGenerator;

    $baseRules = [
        'gates' => ['adx_min' => 24, 'sentiment' => ['mode' => 'contrarian']],
        'execution' => ['rr' => 2.0, 'sl_atr_mult' => 2.0, 'tp_atr_mult' => 4.0],
        'risk' => ['per_trade_pct' => ['default' => 1.0]],
    ];

    $baseline = new ResolvedRules(
        base: $baseRules,
        marketOverrides: [],
        emergencyOverrides: [],
        metadata: [],
        tag: 'test-unique'
    );

    $config = new CalibrationConfig(
        tag: '2025-W42',
        periodStart: CarbonImmutable::create(2025, 10, 13),
        periodEnd: CarbonImmutable::create(2025, 10, 19),
        dryRun: false,
        activate: false,
        shadowMode: false
    );

    $dataset = new CalibrationDataset('2025-W42', [], [], [], []);

    $candidates = $generator->generate($config, $baseline, $dataset);

    $ids = $candidates->pluck('id');
    $uniqueIds = $ids->unique();

    // All IDs should be unique
    expect($ids->count())->toBe($uniqueIds->count());

    // IDs should follow expected patterns
    expect($ids->first())->toBe('2025-W42-baseline');
    expect($ids->filter(fn ($id) => str_contains($id, 'grid'))->count())->toBeGreaterThan(0);
});
