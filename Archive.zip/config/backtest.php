<?php

return [
    'enabled' => env('BACKTEST_MODE', false),
];
