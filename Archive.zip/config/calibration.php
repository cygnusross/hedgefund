<?php

return [
    // Number of Monte Carlo runs to perform in production / default
    'budgets' => [
        // Stage 1 coarse grid count
        'stage1_count' => env('CAL_STAGE1_COUNT', 300),
        // Stage 2 refined candidates
        'stage2_count' => env('CAL_STAGE2_COUNT', 160),
        // How many top candidates to send to Monte Carlo
        'top_n_mc' => env('CAL_TOP_N_MC', 10),
        // Monte Carlo runs per candidate
        'mc_runs' => env('CAL_MC_RUNS', 200),
    ],

    // Allow explicitly skipping Monte Carlo via env/config for CI/testing
    'mc_skip' => env('MC_SKIP', false),

    // Backwards-compatible individual keys
    'monte_carlo_runs' => env('MONTE_CARLO_RUNS', 200),
    'monte_carlo_runs_testing' => env('MONTE_CARLO_RUNS_TESTING', 20),

    // When true, the calibration pipeline will short-circuit persistence and
    // heavy IO during the testing environment and return a simulated result.
    'simulate_in_testing' => env('CALIBRATION_SIMULATE_IN_TESTING', true),
];
