<?php

return [
    // Minutes before a high-impact event is considered a blackout
    'blackout_minutes_high' => 60,
];
