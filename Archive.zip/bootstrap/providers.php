<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\IgServiceProvider::class,
    App\Providers\SpreadServiceProvider::class,
];
